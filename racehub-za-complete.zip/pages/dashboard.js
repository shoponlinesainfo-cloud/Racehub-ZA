export default function Dashboard(){
  return(
    <div style={{padding:40}}>
      <h2>Dashboard</h2>
      <p>Driver stats, club control, subscriptions & admin tools appear here.</p>
    </div>
  )
}